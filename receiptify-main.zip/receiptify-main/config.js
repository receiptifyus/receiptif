/**
 * Open your spotify dashboard
 * https://beta.developer.spotify.com/dashboard
 */

const client_id = 'YOUR_CLIENT_ID';
const redirect_uri = 'YOUR_CALLBACK_URL';
const client_secret = 'YOUR_CLIENT_SECRET';